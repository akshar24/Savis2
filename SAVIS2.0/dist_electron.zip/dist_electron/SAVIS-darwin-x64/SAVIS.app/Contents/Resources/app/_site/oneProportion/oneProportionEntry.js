import {OneProportion} from './oneProportion.js';
window.oneProportion = new OneProportion(document.getElementById('one-proportion'));

