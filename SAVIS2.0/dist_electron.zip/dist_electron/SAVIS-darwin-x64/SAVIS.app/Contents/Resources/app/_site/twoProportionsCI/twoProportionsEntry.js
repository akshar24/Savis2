import {TwoProportions} from './twoProportions.js';
window.twoProportions = new TwoProportions(document.getElementById('two-proportions'));

