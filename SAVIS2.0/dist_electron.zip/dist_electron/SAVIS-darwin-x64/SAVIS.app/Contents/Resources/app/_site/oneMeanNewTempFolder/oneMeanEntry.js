import {OneMean} from './oneMean.js';
window.oneMean = new OneMean(document.getElementById('one-mean'));

