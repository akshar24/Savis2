import {OneProportion} from './oneProportions.js';
window.oneProportion = new OneProportion(document.getElementById('one-proportionCI'));

