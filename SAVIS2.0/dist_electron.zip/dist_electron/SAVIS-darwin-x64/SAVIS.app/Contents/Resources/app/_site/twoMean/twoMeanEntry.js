import {TwoMean} from './twoMean.js';
window.twoMean = new TwoMean(document.getElementById('two-mean'));

